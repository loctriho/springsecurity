package org.baeldung.config;


import ch.qos.logback.core.boolex.EvaluationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {



    @RequestMapping(value ="/cc")
    public @ResponseBody String kk(){

        return "cccccccc";
    }
}
